import {Component, inject, OnInit, signal, WritableSignal} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {WebcamImage, WebcamModule} from 'ngx-webcam';
import {firstValueFrom, Observable, Subject} from 'rxjs';

import {MessageService} from 'primeng/api';
import {CardModule} from 'primeng/card';
import {ButtonModule} from 'primeng/button';
import {ToastModule} from 'primeng/toast';
import {InputTextModule} from 'primeng/inputtext';
import {Tag} from 'primeng/tag';
import {Divider} from 'primeng/divider';
import {ProgressSpinner} from 'primeng/progressspinner';

import {SubjectPortalService} from '../../services/subject-portal.service';
import {ArcoService} from '../../services/arco.service';

import {SubjectPortalDto} from '../../dtos/arco-management/subject-portal-dto';
import {SubjectLookupDto} from '../../dtos/arco-management/subject-lookup-dto';

type PortalStep =
  | 'lookup'
  | 'loading'
  | 'no-biometric'
  | 'register-biometric'
  | 'verify-biometric'
  | 'data';

@Component({
  selector: 'app-subject-portal',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    WebcamModule,
    CardModule,
    ButtonModule,
    ToastModule,
    InputTextModule,
    Tag,
    Divider,
    ProgressSpinner,
  ],
  providers: [MessageService],
  templateUrl: './subject-portal.html',
})
export class SubjectPortal implements OnInit {

  private readonly service = inject(SubjectPortalService);

  private readonly arcoService = inject(ArcoService);

  readonly messageService = inject(MessageService);

  identification: WritableSignal<string> = signal('');

  subjectId: WritableSignal<string> = signal('');

  subjectLookup: WritableSignal<SubjectLookupDto | null> = signal(null);

  step: WritableSignal<PortalStep> = signal('lookup');

  subjectData: WritableSignal<SubjectPortalDto | null> = signal(null);

  loading: WritableSignal<boolean> = signal(false);

  error: WritableSignal<string> = signal('');

  private webcamTrigger = new Subject<void>();

  get triggerObservable(): Observable<void> {
    return this.webcamTrigger.asObservable();
  }

  cameraActive: WritableSignal<boolean> = signal(false);

  imagePreview: WritableSignal<string | null> = signal(null);

  imageBase64: WritableSignal<string> = signal('');

  readonly consentText =
    'Autorizo el tratamiento de mis datos biométricos faciales conforme a la Ley Orgánica de Protección de Datos Personales del Ecuador (LOPDP).';

  ngOnInit(): void {}

  async searchSubject(): Promise<void> {

    if (!this.identification().trim()) {

      this.messageService.add({
        severity: 'warn',
        summary: 'Campo requerido',
        detail: 'Ingrese una identificación.',
      });

      return;
    }

    this.loading.set(true);

    try {

      const lookup = await firstValueFrom(
        this.arcoService.lookupSubject(this.identification())
      );

      this.subjectLookup.set(lookup);

      this.subjectId.set(lookup.id);

      const data = await firstValueFrom(
        this.service.getMyData(lookup.id)
      );

      this.subjectData.set(data);

      this.step.set(
        lookup.hasBiometrics
          ? 'verify-biometric'
          : 'no-biometric'
      );

    } catch {

      this.messageService.add({
        severity: 'error',
        summary: 'No encontrado',
        detail:
          'No existe información asociada a la identificación ingresada.',
      });

    } finally {
      this.loading.set(false);
    }
  }

  openCamera(): void {
    this.imagePreview.set(null);
    this.imageBase64.set('');
    this.cameraActive.set(true);
  }

  takeSnapshot(): void {
    this.webcamTrigger.next();
  }

  handleImage(img: WebcamImage): void {
    this.imageBase64.set(img.imageAsBase64);
    this.imagePreview.set(img.imageAsDataUrl);
    this.cameraActive.set(false);
  }

  retake(): void {
    this.imagePreview.set(null);
    this.imageBase64.set('');
    this.cameraActive.set(true);
  }

  async registerBiometric(): Promise<void> {

    if (!this.imageBase64()) {
      return;
    }

    this.loading.set(true);

    try {

      await firstValueFrom(
        this.service.registerBiometric(this.subjectId(), {
          imageBase64: this.imageBase64(),
          consentText: this.consentText,
        })
      );

      this.messageService.add({
        severity: 'success',
        summary: 'Biometría registrada',
        detail: 'Registro exitoso.',
      });

      const data = await firstValueFrom(
        this.service.getMyData(this.subjectId())
      );

      this.subjectData.set(data);

      this.step.set('data');

    } catch (err: unknown) {

      const e = err as {error?: {message?: string}};

      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail:
          e?.error?.message ??
          'No se pudo registrar la biometría.',
      });

    } finally {
      this.loading.set(false);
    }
  }

  async verifyBiometric(): Promise<void> {

    if (!this.imageBase64()) {
      return;
    }

    this.loading.set(true);

    try {

      const result = await firstValueFrom(
        this.service.verifyBiometric(this.subjectId(), {
          imageBase64: this.imageBase64(),
        })
      );

      if (result.verified) {

        this.messageService.add({
          severity: 'success',
          summary: 'Validación correcta',
          detail: 'Identidad validada exitosamente.',
        });

        this.step.set('data');
      }

    } catch {

      this.messageService.add({
        severity: 'error',
        summary: 'Validación fallida',
        detail:
          'No se pudo validar la identidad.',
      });

    } finally {
      this.loading.set(false);
    }
  }
}

export const environment = {
  production: false,
  keycloak: {
    url: 'https://157.137.208.39:8443/',
    realm: 'develop',
    clientId: 'SecureHub'
  },
  baseUrl: "http://des-apis.securehub.com"
};
